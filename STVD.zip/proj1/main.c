
#include "stm8s.h"
#include "milis.h"      //inkludov�n� knihoven
#include "swi2c.h"

#define SEGMENT_A_PORT GPIOB
#define SEGMENT_B_PORT GPIOB
#define SEGMENT_C_PORT GPIOB    //Makra pro jednotliv� segmenty (port B)
#define SEGMENT_D_PORT GPIOB
#define SEGMENT_E_PORT GPIOB
#define SEGMENT_F_PORT GPIOB
#define SEGMENT_G_PORT GPIOB

#define SEGMENT_A_PIN GPIO_PIN_1
#define SEGMENT_B_PIN GPIO_PIN_2
#define SEGMENT_C_PIN GPIO_PIN_3    //Makra pro jednotliv� segmenty (piny PB1 - PB7)
#define SEGMENT_D_PIN GPIO_PIN_4
#define SEGMENT_E_PIN GPIO_PIN_5
#define SEGMENT_F_PIN GPIO_PIN_6
#define SEGMENT_G_PIN GPIO_PIN_7

#define DIGIT_1_PORT GPIOG
#define DIGIT_2_PORT GPIOG    //Makra pro sp�n�n� jednotliv�ch digit� (port G)
#define DIGIT_3_PORT GPIOG
#define DIGIT_4_PORT GPIOG
#define DIGIT_5_PORT GPIOG
#define DIGIT_6_PORT GPIOG

#define DIGIT_1_PIN GPIO_PIN_1
#define DIGIT_2_PIN GPIO_PIN_2    //Makra pro sp�n�n� jednotliv�ch digit� (piny PG1 - PG6)
#define DIGIT_3_PIN GPIO_PIN_3
#define DIGIT_4_PIN GPIO_PIN_4
#define DIGIT_5_PIN GPIO_PIN_5
#define DIGIT_6_PIN GPIO_PIN_6


#define RTC_ADRESS 0b11010000    //Makro pro adresu RTC obvodu


//PB0 - 1 1 1 1 1 1 1 1 1 1
//PB1 A 0 1 0 0 1 0 0 0 0 0
//PB2 B 0 0 0 0 0 1 1 0 0 0
//PB3 C 0 0 1 0 0 0 0 0 0 0
//PB4 D 0 1 0 0 1 0 0 1 0 0
//PB5 E 0 1 0 1 1 1 0 1 0 1
//PB6 F 0 1 1 1 0 0 0 1 0 0
//PB7 G 1 1 0 0 0 0 0 1 0 0

//      0 1 2 3 4 5 6 7 8 9



void read_RTC(void);   //funkce, kter� ka�d�ch 100 ms vy��t� informace z RTC
void process_RTC(void);  //funkce, kter� n�m vy�ten� hodnoty p�evede 
void GPIO_Set(void);   //funkce, kter� inicializuje pot�ebn� piny
void init_timer(void);  //funkce, kter� nastav� timer 3 



volatile uint8_t error;
volatile uint8_t RTC_precteno[7];    // pole o d�lce 7 byt�, kam ukl�d�m data o �ase
volatile uint8_t zapis[7];				   //pole o d�lce 7 byt�, ze kter�ho zapisuju data do RTC



void set_pwm(void);   //funkce, kter� nastav� parametry Timeru 2
void pwm_change(void);   //funkce, kter� se star� o st��d�n� LED diod a zm�ny st��d



uint8_t pomocna_promenna1 = 0; //prom�nn� zaji��uje vstup do spr�vn� podm�nky u PWM (aby se LEDky st��daly)
uint8_t pomocna_promenna2 = 0;



#define time 2   //�as mezi zm�nami st��dy u PWM
#define TIMER_TOP (16000-1)  //strop �asova�e je 16000 impulz�  




const uint16_t znak[] =  //pole obsahuj�c� znaky, kter� zapisuju
{
	0b10000000,  //0
	0b11110011,  //1
	0b01001001,  //2
	0b01100001,  //3
	0b00110011,  //4
	0b00100101,  //5
	0b00000101,  //6
	0b11110001,  //7
	0b00000001,  //8
	0b00100001,  //9
};

uint8_t sec;        //prom�nn� pro zpracov�n� dat z RTC a zaps�n� dat na displeje
uint8_t des_sec;

uint8_t min;
uint8_t des_min;

uint8_t hod;
uint8_t des_hod;

uint8_t zbytek_hod;




void main(void){
CLK_HSIPrescalerConfig(CLK_PRESCALER_HSIDIV1); // 16MHz z intern�ho RC oscil�toru
init_milis(); 
set_pwm();   
swi2c_init();
GPIO_Set();
init_timer();
enableInterrupts();  //glob�ln� povol� p�eru�en�


zapis[0] = 0b00000000;   //hodnoty zapisovan� do RTC obvodu
zapis[1] = 0b00000101;
zapis[2] = 0b00100011;

swi2c_write_buf(RTC_ADRESS,0x00,zapis,3);   //z�pis dat do RTC obvodu

  while (1){       //nekone�n� smy�ka
		read_RTC();
    process_RTC();
		pwm_change();
  }
}


void pwm_change(void){
	
static int16_t strida2 = 0;	  //st��da �erven�ch LED
static int16_t strida1 = 0;   //st��da �lut�ch LED  
static uint16_t minuly_cas = 0;   //po��t��n� hodnota �asu pro porovn�v�n� v podm�nk�ch

if(pomocna_promenna1 == 0 && pomocna_promenna2 == 0){    //�lut� LED se rozsv�c�
  if((milis() - minuly_cas) >= time){
    strida1=strida1+200;      
	  minuly_cas=milis();
    if(strida1 >= TIMER_TOP){pomocna_promenna1=1;}	
    TIM2_SetCompare1(strida1);   // nastav st��du kan�lu 1 (TIM2_CH1,  PD4)
  }
}

if(pomocna_promenna1 == 1 && pomocna_promenna2 == 0){    //�lut� LED zhas�naj�
  if((milis() - minuly_cas) >= time){
    strida1=strida1-200;       
	  minuly_cas=milis();
    if(strida1 <= 0)
		{
		 pomocna_promenna2=1;
		}	
    TIM2_SetCompare1(strida1);   // nastav st��du kan�lu 1 (TIM2_CH1,  PD4)
  }
}

if(pomocna_promenna1 == 1 && pomocna_promenna2 == 1){    //�erven� LED se rozsv�c� (dvakr�t pomaleji ne� �lut�)
  if((milis() - minuly_cas) >= time){
    strida2=strida2+100;       
	  minuly_cas=milis();
    if(strida2 >= TIMER_TOP){pomocna_promenna1=0;}	
    TIM2_SetCompare2(strida2);   // nastav st��du kan�lu 2 (TIM2_CH2,  PD3)
  }
}

if(pomocna_promenna1 == 0 && pomocna_promenna2 == 1){    //�erven� LED zhas�naj� (dvakr�t pomaleji ne� �lut�)
  if((milis() - minuly_cas) >= time){
    strida2=strida2-100;       
	  minuly_cas=milis();
    if(strida2 <= 0)
		{
		 pomocna_promenna2=0;
		}	
    TIM2_SetCompare2(strida2);   // nastav st��du kan�lu 2 (TIM2_CH2,  PD3)
  }


}
}


void set_pwm(void){
	
GPIO_Init(GPIOD, GPIO_PIN_4, GPIO_MODE_OUT_PP_LOW_SLOW);	  //nastav�m piny pro PWM
GPIO_Init(GPIOD, GPIO_PIN_3, GPIO_MODE_OUT_PP_LOW_SLOW);
	
TIM2_TimeBaseInit(TIM2_PRESCALER_1, TIMER_TOP);	   //inicializace �asov� z�kladny
	
	
	TIM2_OC1Init(  //kan�l 1 (TM2_CH1)    
				TIM2_OCMODE_PWM1, 	 
				TIM2_OUTPUTSTATE_ENABLE,
				0,
				TIM2_OCPOLARITY_HIGH);   				//Rozsv�c�m �rovn� HIGH (oba kan�ly timeru 2)
				
				
	TIM2_OC2Init(  //kan�l 2 (TM2_CH2)    
				TIM2_OCMODE_PWM1, 	 
				TIM2_OUTPUTSTATE_ENABLE,
				0,
				TIM2_OCPOLARITY_HIGH); 			
				
				
// aktivuji na v�ech kan�lech preload (zaji��uje zm�nu st��dy bez ne��douc�ch efekt�)				
TIM2_OC1PreloadConfig(ENABLE);
TIM2_OC2PreloadConfig(ENABLE);
TIM2_OC3PreloadConfig(ENABLE);
TIM2_Cmd(ENABLE);  // spust�me timer 2
}



INTERRUPT_HANDLER(TIM3_UPD_OVF_BRK_IRQHandler, 15){    //funkce pro obsluhu displej�
static  uint8_t digit = 1;
  TIM3_ClearITPendingBit(TIM3_IT_UPDATE);

  if(digit == 1){
		GPIO_WriteHigh(DIGIT_6_PORT,DIGIT_6_PIN);
	  GPIO_WriteLow(DIGIT_1_PORT,DIGIT_1_PIN);
    GPIO_Write(SEGMENT_A_PORT,znak[sec]);   		    //sekundy
  	//GPIO_WriteHigh(DIGIT_1_PORT,DIGIT_1_PIN);
		
	}else if(digit == 2){
		GPIO_WriteHigh(DIGIT_1_PORT,DIGIT_1_PIN);
		GPIO_WriteLow(DIGIT_2_PORT,DIGIT_2_PIN);
    GPIO_Write(SEGMENT_B_PORT,znak[des_sec]);       //des�tky sekund
	  //GPIO_WriteHigh(DIGIT_2_PORT,DIGIT_2_PIN);
		
  }else if(digit == 3){
		GPIO_WriteHigh(DIGIT_2_PORT,DIGIT_2_PIN);
		GPIO_WriteLow(DIGIT_3_PORT,DIGIT_3_PIN);
    GPIO_Write(SEGMENT_C_PORT,znak[min]);           //minuty
	 // GPIO_WriteHigh(DIGIT_3_PORT,DIGIT_3_PIN);
		
  }else if(digit == 4){
		GPIO_WriteHigh(DIGIT_3_PORT,DIGIT_3_PIN);
		GPIO_WriteLow(DIGIT_4_PORT,DIGIT_4_PIN);
    GPIO_Write(SEGMENT_D_PORT,znak[des_min]);       //des�tky minut
	  //GPIO_WriteHigh(DIGIT_4_PORT,DIGIT_4_PIN);
		
	}else if(digit == 5){
		GPIO_WriteHigh(DIGIT_4_PORT,DIGIT_4_PIN);
		GPIO_WriteLow(DIGIT_5_PORT,DIGIT_5_PIN);
    GPIO_Write(SEGMENT_E_PORT,znak[hod]);          //hodiny
	  //GPIO_WriteHigh(DIGIT_5_PORT,DIGIT_5_PIN);
		
	}else if(digit == 6){
		GPIO_WriteHigh(DIGIT_5_PORT,DIGIT_5_PIN);
		GPIO_WriteLow(DIGIT_6_PORT,DIGIT_6_PIN);
    GPIO_Write(SEGMENT_F_PORT,znak[des_hod]);        //des�tky hodin
	  //GPIO_WriteHigh(DIGIT_6_PORT,DIGIT_6_PIN);
  }
	
  digit++;      //inkrementuju prom�nnou digit o 1
	if(digit > 6){   //pokud je digit = 7, nastav� se zp�t na 1
		digit = 1;
	}
}
 
 
 
 
void read_RTC(void){
static uint16_t last_time=0;      // ka�d�ch 100ms p�e�te obsah RTC
  if(milis() - last_time >= 100){
    last_time = milis(); 
    error=swi2c_read_buf(RTC_ADRESS,0x00,RTC_precteno,7); 
  }
}




void process_RTC(void){   //zpracov�n� dat z RTC
  sec = (RTC_precteno[0] & 0b00001111);              //sekundy
  des_sec = ((RTC_precteno[0] >> 4) & 0b00001111);		 //des�tky sekund
	min = (RTC_precteno[1] & 0b00001111);		                //minuty
	des_min = ((RTC_precteno[1] >> 4) & 0b00001111);   //des�tky minut
	hod = (RTC_precteno[2] & 0b00001111); 						//hodiny
	des_hod = ((RTC_precteno[2] >> 4) & 0b00000011);  //des�tky hodin
	zbytek_hod = ((RTC_precteno[2] >> 4) & 0b00001111);   //zbytek dat hodin 
}




void GPIO_Set(void){     //Inicializace pin�, nastavuju na HIGH, jeliko� rozsv�c�m nulou 
	GPIO_Init(SEGMENT_A_PORT,SEGMENT_A_PIN,GPIO_MODE_OUT_PP_HIGH_SLOW);
	GPIO_Init(SEGMENT_B_PORT,SEGMENT_B_PIN,GPIO_MODE_OUT_PP_HIGH_SLOW);
	GPIO_Init(SEGMENT_C_PORT,SEGMENT_C_PIN,GPIO_MODE_OUT_PP_HIGH_SLOW);
	GPIO_Init(SEGMENT_D_PORT,SEGMENT_D_PIN,GPIO_MODE_OUT_PP_HIGH_SLOW);
	GPIO_Init(SEGMENT_E_PORT,SEGMENT_E_PIN,GPIO_MODE_OUT_PP_HIGH_SLOW);
	GPIO_Init(SEGMENT_F_PORT,SEGMENT_F_PIN,GPIO_MODE_OUT_PP_HIGH_SLOW);
	GPIO_Init(SEGMENT_G_PORT,SEGMENT_G_PIN,GPIO_MODE_OUT_PP_HIGH_SLOW);
	
	GPIO_Init(DIGIT_1_PORT,DIGIT_1_PIN,GPIO_MODE_OUT_PP_HIGH_SLOW);
	GPIO_Init(DIGIT_2_PORT,DIGIT_2_PIN,GPIO_MODE_OUT_PP_HIGH_SLOW);
	GPIO_Init(DIGIT_3_PORT,DIGIT_3_PIN,GPIO_MODE_OUT_PP_HIGH_SLOW);
	GPIO_Init(DIGIT_4_PORT,DIGIT_4_PIN,GPIO_MODE_OUT_PP_HIGH_SLOW);
	GPIO_Init(DIGIT_5_PORT,DIGIT_5_PIN,GPIO_MODE_OUT_PP_HIGH_SLOW);
	GPIO_Init(DIGIT_6_PORT,DIGIT_6_PIN,GPIO_MODE_OUT_PP_HIGH_SLOW);
}



void init_timer(void){
TIM3_TimeBaseInit(TIM3_PRESCALER_16,1999); // clock 1MHz, strop 5000 => perioda p�ete�en� 5 ms
TIM3_ITConfig(TIM3_IT_UPDATE, ENABLE); // povol�me p�eru�en� od update ud�losti (p�ete�en�) timeru 3
TIM3_Cmd(ENABLE); // spust�me timer 3
}






// pod t�mto koment�oem nic nemiote 
#ifdef USE_FULL_ASSERT

/**
  * @brief  Reports the name of the source file and the source line number
  *   where the assert_param error has occurred.
  * @param file: pointer to the source file name
  * @param line: assert_param error line source number
  * @retval : None
  */
void assert_failed(u8* file, u32 line)
{ 
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */

  /* Infinite loop */
  while (1)
  {
  }
}
#endif


/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
